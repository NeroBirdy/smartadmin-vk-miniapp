import{i as e}from"./CkqUjbU7.js";const s=e({}),t=e(null);function n(){return{lessonsMap:s,selectedDateKey:t}}export{n as u};
